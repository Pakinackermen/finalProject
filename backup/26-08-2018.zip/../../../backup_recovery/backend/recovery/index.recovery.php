<?php

$getfilethis =  getfileme(date("d-m-Y").".zip", "");

// unzipfile(localfile);
unzipfile($getfilethis['namefile']);

// removedirfile('/'.'ftp file');
removedirfile('/'.$getfilethis["ftppath"]);

// makedirfile('local file', 'ftp file');
makedirfile('New', $getfilethis["ftppath"]);

echo "sucees";
?>