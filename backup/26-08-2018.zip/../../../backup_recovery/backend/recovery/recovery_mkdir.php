<?php 
    // makedirfile('name file it dir', 'sub path in connect to ftp');
function makedirfile($namedir, $subpath)
{
  include 'configftp.php';

  foreach (directoryToArray($namedir,true) as $key) {

    $dirname = $subpath."/".dirname($key);

    // check dir by FTP
     if ( !is_dir("ftp://$ftp_user_name:$ftp_user_pass@$server/".$subpath."/".dirname($key) )) {

       //create dir
       ftp_mkdir($connection, $dirname );
       echo "<div style='font-family: monospace;'>
             successfully created dir........". dirname($key)."...........OK<div>";
     }
     // create file
     // ftp_put(desination, souece)
      if ( ftp_put($connection, $dirname .'/'. basename($key), dirname($key) .'/'. basename($key), FTP_BINARY) ) {
        echo "<div style='font-family: monospace;'>
              successfully created file........". basename($key)."...........OK<div>";
      }
    }
    ftp_close($connection);
    return 0;
  }
?>