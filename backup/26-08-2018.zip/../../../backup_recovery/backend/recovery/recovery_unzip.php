<?php

date_default_timezone_set("Asia/Bangkok");


// getfileme('path file new', 'path file older');
function getfileme($namefile, $ftppath){
 
  include 'config/ftp.php';  
  if (ftp_get($connection, $namefile, "$ftppath/$namefile", FTP_BINARY) ) {
  }
  ftp_close($connection);
  $getfile['namefile'] = $namefile;
  $getfile['ftppath'] = $ftppath;

  return $getfile;
}

// unzip
// unzip('mi.zip');
function unzipfile($namefileunzip)
{
  $filename = '';

  include 'configftp.php';

  $zip = new ZipArchive;
  if ($zip->open($namefileunzip) === TRUE) {
       for ($i = 0; $i < $zip->numFiles; $i++) {
         $filename = $zip->getNameIndex(0);
           // echo dirname($filename);
      }
      echo 'Unzip.........OK';
      $zip->extractTo(dirname(__FILE__));
       // echo ftp_pwd($connection);
       // ftp_delete($connection, 'abc2');
       // ftp_rmdir($connection, '/abc2');
       // ftp_close($connection);
       $zip->close();
  } else {
      echo 'Unzip failed';
  }
  return $filename;
}





  

   ?>
