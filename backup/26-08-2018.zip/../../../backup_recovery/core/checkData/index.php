<div class="col-lg-6">
  <!-- Page Header -->
  <div class="page-header row no-gutters py-4">
    <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
      <!-- <span class="text-uppercase page-subtitle">Overview</span> -->
      <h3 class="page-title">ระบบตรวจสอบ</h3>
    </div>
  </div>
  <!-- End Page Header -->
  <div class="card card-small mb-4">
    <div class="card-header border-bottom">
      <h6 class="m-0">ตรวจสอบข้อมูล</h6>
    </div>

    <ul class="list-group list-group-flush">
      <li class="list-group-item p-4">
        <div class="row">
          <div class="col">
            <form>
              <div class="form-row h-10">
                <div class="form-group col-md-12">
                  <label>เลือกไดเรกทอรี่ที่ต้องการ</label>
                  <select id="pathBackup" class="form-control">
                    <option selected>ตรวจสอบไดเรกทอรี่...</option>
                    <option>Path 1</option>
                    <option>Path 2</option>
                  </select>
                </br>
                 
                  <span class="d-flex justify-content-center">
                    <button type="submit" class="btn btn-accent col-md-3 ">ยืนยัน</button>
                  </span>
                  
            </form>
            </div>
            </div>
      </li>
    </ul>
    </div>
    </div>
   
  

