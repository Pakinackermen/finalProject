<?php
include 'main.php';
// CreateFileHashCheck('dirname in FTP', 'text', 'filename');
CreateFileHashCheck('', 'Backup', 'hashbackup.txt');
 ?>
