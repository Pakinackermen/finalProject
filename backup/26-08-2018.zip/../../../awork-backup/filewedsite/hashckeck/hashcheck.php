<?php

include 'main.php';
// CreateFileHashCheck('dirname in ftp', 'text', 'filename');
CreateFileHashCheck('', 'Check', 'chackhash.txt');
 ?>
