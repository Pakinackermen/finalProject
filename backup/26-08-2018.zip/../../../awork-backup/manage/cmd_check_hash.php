<?php 
// ไฟล์ตรวจสอบการการส่งไฟล์ Hash Run in command
    while(true){
        // sleep(second 60*60)
        sleep(1);
        echo 'Now:       '. date('Y-m-d h:i:s') ."\n";
    }
    

?>